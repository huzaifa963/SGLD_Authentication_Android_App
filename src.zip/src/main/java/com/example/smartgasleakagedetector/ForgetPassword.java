package com.example.smartgasleakagedetector;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Html;
import android.widget.Button;
import android.widget.EditText;

public class ForgetPassword extends AppCompatActivity {
EditText passcode;
Button bsubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgetpassword);
        getSupportActionBar() .setTitle(Html.fromHtml("<font color=\"#FFA000\">" + getString(R.string.app_name) + "</font>"));
        passcode=findViewById(R.id.passcode);
        bsubmit= findViewById(R.id.bsubmit);
    }
}