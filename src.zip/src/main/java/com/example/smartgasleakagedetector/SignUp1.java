package com.example.smartgasleakagedetector;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp1 extends AppCompatActivity {
    TextInputLayout  username,regPhoneNo,regPassword;
    Button bnext;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup1);
        getSupportActionBar() .setTitle(Html.fromHtml("<font color=\"#FFA000\">" + getString(R.string.app_name) + "</font>"));
        bnext = findViewById(R.id.bnext);
        username = findViewById(R.id.user_name);
        regPhoneNo = findViewById(R.id.phone_number);
        regPassword = findViewById(R.id.enter_password);
        bnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser(v);
            }
        });
    }
    private Boolean validateUsername() {

        String val = username.getEditText().getText().toString();
        System.out.println(val);
        //String noWhiteSpace = "\A\w{4,20}\z";

        if (val.isEmpty()) {
            username.setError("Field cannot be empty");
            return false;
        } else if (val.length() >= 15) {
            username.setError("Username too long");
            return false;
        }/*** else if (!val.matches(noWhiteSpace)) {
         username.setError("White Spaces are not allowed");
         return false;
         }***/
        else {
            username.setError(null);
            return true;
        }
    }

    private Boolean validatePhoneNo() {
        String val = regPhoneNo.getEditText().getText().toString();

        if (val.isEmpty()) {
            regPhoneNo.setError("Field cannot be empty");
            return false;
        } else {
            regPhoneNo.setError(null);

            return true;
        }
    }

    private Boolean validatePassword() {
        String val = regPassword.getEditText().getText().toString();
        /***String passwordVal = "^" +
         //"(?=.*[0-9])" +         //at least 1 digit
         //"(?=.*[a-z])" +         //at least 1 lower case letter
         //"(?=.*[A-Z])" +         //at least 1 upper case letter
         "(?=.*[a-zA-Z])" +      //any letter
         "(?=.*[@#$%^&+=])" +    //at least 1 special character
         "(?=\S+$)" +           //no white spaces
         ".{4,}" +               //at least 4 characters
         "$";***/

        if (val.isEmpty()) {
            regPassword.setError("Field cannot be empty");
            return false;
        } /***else if (!val.matches(passwordVal)) {
         regPassword.setError("Password is too weak");
         return false;
         } ***/
        else {
            regPassword.setError(null);

            return true;
        }
    }

    public void registerUser(View view) {
        if (!validatePassword() | !validatePhoneNo() | !validateUsername()) {
            return;
        }
        String username1 = username.getEditText().getText().toString();
        String phoneNo = regPhoneNo.getEditText().getText().toString();
        String password = regPassword.getEditText().getText().toString();
        //bnext= findViewById(R.id.bnext);
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("User");
        UserHelperClass helperclass = new UserHelperClass(username1, phoneNo, password);
        reference.child(username1).setValue(helperclass);
        Intent intent;
        intent = new Intent(SignUp1.this, Login.class);
        Toast.makeText(SignUp1.this, "Details Saved", Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }



    /***bnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (registerUser(view) != 0) {
                    username = findViewById(R.id.username);
                    String username1 = username.getText().toString();
                    regPhoneNo = findViewById(R.id.phonenumber);
                    String phoneNo = regPhoneNo.getText().toString();
                    regPassword = findViewById(R.id.enterpassword);
                    String password = regPassword.getText().toString();
                    //bnext= findViewById(R.id.bnext);
                    rootNode = FirebaseDatabase.getInstance();
                    reference = rootNode.getReference("User");
                    UserHelperClass helperclass = new UserHelperClass(username1, phoneNo, password);
                    reference.child(username1).setValue(helperclass);
                    Intent intent;
                    intent = new Intent(SignUp1.this, SignUp2.class);
                    startActivity(intent);
                }
            }
        });***/
}

