package com.example.smartgasleakagedetector;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ResetPassword extends AppCompatActivity {
EditText enterpassword;
EditText confirmpassword;
Button bnext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup2);

        enterpassword =findViewById(R.id.enterpassword);
        confirmpassword=findViewById(R.id.confirmpassword);
        bnext=findViewById(R.id.bnext);

        bnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(ResetPassword.this, Login.class);
                startActivity(intent);
            }
        });
    }
}