package com.example.smartgasleakagedetector;

import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import static com.android.volley.toolbox.Volley.newRequestQueue;

public class RoomEnvironment extends AppCompatActivity {
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.roomenvironment);
        getSupportActionBar().setTitle(Html.fromHtml("<font color=\"#FFA000\">" + getString(R.string.app_name) + "</font>"));
        tv = findViewById(R.id.tv);
    }

/***
    public void get(View v)
    {
        String apikey = "683fda7cbcb7ba6eaef465dc4a5dc0dc";
        //not complete url, we need to add city name and key.
        // String url= "api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}";

        //this is for mianwali only
        //1. String url= "https://api.openweathermap.org/data/2.5/weather?q=islamabad&appid=683fda7cbcb7ba6eaef465dc4a5dc0dc"
        //2. String url ="https://api.openweathermap.org/data/2.5/weather?q=mianwali&appid=683fda7cbcb7ba6eaef465dc4a5dc0dc"

        //To make it generic we need to get the city set the city name in this place.
        //https://api.openweathermap.org/data/2.5/weather?q=namal&appid=683fda7cbcb7ba6eaef465dc4a5dc0dc
        //String url ="https://api.openweathermap.org/data/2.5/weather?q="+cname+"&appid=683fda7cbcb7ba6eaef465dc4a5dc0dc";
        String url =  "https://api.openweathermap.org/data/2.5/weather?q=namal&appid=683fda7cbcb7ba6eaef465dc4a5dc0dc"

       // RequestQueue queue = new newRequestQueue(getApplicationContext());
        RequestQueue queue= Volley.newRequestQueue(getApplicationContext());
        JsonObjectRequest request= new JsonObjectRequest(Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject object = response.getJSONObject("main");
                            String temperature = object.getString("temp"); //we need temp so only we will take temp from main.
                            Double temp = Double.parseDouble(temperature) - 273.15;
                            //set this temp in text view (tv)
                            tv.setText("Temperature is " + temp.toString().substring(0, 5) + " C");
                        } catch (JSONException e) {
                            e.printStackTrace();

                        }
                    }},
                new Response.ErrorListener() {
                    @Override
                    //for handling errors
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(RoomEnvironment.this, "Please Check City Name", Toast.LENGTH_SHORT).show(); //display the real error on the screen.
                    }
                }
                );
                queue.add(request);
                }***/
    }


                //<JSONObject>() {
/***
*//*@Override
            public void onResponse(JSONObject response) {
                try {
                    JSONObject object= response.getJSONObject("main"); //this has all data from main (this main contain entire main document but we don't need that
                    String temperature = object.getString("temp"); //we need temp so only we will take temp from main.
                    //usually temperature is recorded in Kelvin so we wil convert it into Celsius, by doing
                    // C= K-273.15.
                    Double temp=  Double.parseDouble(temperature)-273.15;
                    //set this temp in text view (tv)
                    tv.setText("Temperature is " + temp.toString().substring(0,5)+ " C");
                } catch (JSONException e) {
                    e.printStackTrace();
                    //Showing Exception message.....
                }
            }
        }
        );
        ***/