package com.example.smartgasleakagedetector;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class Dashboard extends AppCompatActivity {
    TextView name,phone;
    ImageButton room;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard);
        getSupportActionBar() .setTitle(Html.fromHtml("<font color=\"#FFA000\">" + getString(R.string.app_name) + "</font>"));
        name=findViewById(R.id.textView2);
        phone=findViewById(R.id.textView3);
        room=findViewById(R.id.roomenvironmet);
        ShowUserData();
        room.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(Dashboard.this, RoomEnvironment.class);
                Toast.makeText(Dashboard.this, "Room Environment Clicked", Toast.LENGTH_SHORT).show();
                startActivity(intent);

            }
        });
    }

    private  void ShowUserData()
    {
        Intent intent=getIntent();
        String username=intent.getStringExtra("username1");
        String phoneno=intent.getStringExtra("phoneNo");
        name.setText(username);
        phone.setText(phoneno);
    }

}