package com.example.smartgasleakagedetector;

public class UserHelperClass {
    String username1,phoneNo,password;

    public UserHelperClass() {
    }

    public UserHelperClass(String username1, String phoneNo, String password) {
        this.username1 = username1;
        this.phoneNo = phoneNo;
        this.password = password;
    }

    public String getUsername1() {
        return username1;
    }

    public void setUsername1(String username1) {
        this.username1 = username1;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
